import { Routes } from '@angular/router';
import { EventsListComponent, EventDetailsComponent, EventCreateComponent } from './events/index';

import { Erro404Component } from './errors/404.component';
import { EventRouteActivator, EventListResolver } from 'src/services/index';

export const routes:Routes = [
  { path: '', redirectTo: '/events', pathMatch: 'full' },
  { path: 'events', component: EventsListComponent, resolve: { events: EventListResolver } },
  { path: 'events/new', component: EventCreateComponent, canDeactivate: ['canDeactiveCreateEvent']},
  { path: 'events/:id', component: EventDetailsComponent, canActivate: [EventRouteActivator] },
  { path: '404', component: Erro404Component },
  { path: 'user', loadChildren: './user/user.module#UserModule' }
];
