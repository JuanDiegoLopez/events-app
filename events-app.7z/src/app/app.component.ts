import { Component } from '@angular/core';

@Component({
  selector: 'app-events',
  templateUrl: './app.component.html'
})

export class AppComponent {
  title = 'events-app';
}
