import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';

import { AppComponent } from './app.component';

import {
  EventsListComponent,
  EventComponent,
  EventDetailsComponent,
  EventCreateComponent
} from './events/index';

import { NavbarComponent } from './nav/navbar.component';
import { Erro404Component } from './errors/404.component';

import {
  EventService,
  ToastrService,
  EventRouteActivator,
  EventListResolver,
  checkDirtyState
} from 'src/services/index';

import { routes } from './routes';
import { AuthService } from 'src/services/auth.service';
import { AuthGuardService } from './guards/auth.guard';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

@NgModule({
  declarations: [
    AppComponent,
    EventsListComponent,
    EventComponent,
    NavbarComponent,
    EventDetailsComponent,
    EventCreateComponent,
    Erro404Component
  ],
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    RouterModule.forRoot(routes)
  ],
  providers: [
    EventService,
    ToastrService,
    EventRouteActivator,
    EventListResolver,
    AuthService,
    AuthGuardService,
    {
      provide: 'canDeactiveCreateEvent',
      useValue: checkDirtyState
    }
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
